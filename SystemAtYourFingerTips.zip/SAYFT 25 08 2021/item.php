<?php
class Item{

var $service_id;
var $service_type;
var $quantity;
var $image;
var $price;
}
?>